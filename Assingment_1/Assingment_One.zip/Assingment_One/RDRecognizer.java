/* Author: Andrew Peklar
 * Prof:   Gordon
 * Class:  CSC135
 * Assingment #1
 *
 */

import java.io.*;
import java.util.Scanner;
//--------------------------------------------
// Recognizer for simple expression grammar
// Written by Anthony Ramirez and adapted from Scott Gordon's
// Recognizer.
// 
//
// to run on Athena (linux) -
// save as: RDRecognizer.java
// compile: javac RDRecognizer.java
// execute: java RDRecognizer
//
// EBNF Grammar is -
// block ::= B {statemt} E [D]
// statemt ::= asignmt | ifstmt | while | inpout | block
// asignmt ::= A ident ~ exprsn
// ifstmt ::= I comprsn T block [L block]
// while ::= W comprsn block
// inpout ::= iosym ident {, ident}
// comprsn ::= ( oprnd opratr oprnd )
// exprsn ::= factor {sumop factor}
// factor ::= oprnd {prodop oprnd}
// oprnd ::= integer | ident | ( exprsn )
// ident ::= letter {char}
// char ::= letter | digit
// integer ::= digit {digit}
// iosym ::= R | O
// opratr ::= < | = | > | !
// sumop ::= + | -
// prodop ::= * | /
// letter ::= X | Y | Z
// digit ::= 0 | 1
// The tokens are: B E D A ~ I T L W , ( ) R O < + > ! + - * / X Y Z 0 1
// Nonterminals are shown as lowercase words.
//--------------------------------------------

public class RDRecognizer {
   static String inputString;
   static int index = 0;
   static int errorflag = 0;
   private char token() {
      return (inputString.charAt(index));
   }
   private void advancePtr() {
      if (index < (inputString.length() - 1)) index++;
   }
   private void match(char T) {
      if (T == token()) advancePtr();
      else error();
   }
   private void error() {
      System.out.println("error at position: " + index);
      errorflag = 1;
      advancePtr();
   }
  //----------------------
   private void block() {
      if (token() == 'B') {
         match(token());
      
      }
      if (token() == 'E') {
         match(token());
      }
      if (token() == 'D') {
         match(token());
      }
   
      while ((token() == 'A') || (token() == '~') || 
      	     (token() == 'I') || (token() == 'L') || 
      	     (token() == 'T') || (token() == 'W') || 
      	     (token() == ')') || (token() == '(') || 
      	     (token() == 'R') || (token() == 'O') || 
      	     (token() == 'X') || (token() == 'Y') || 
      	     (token() == 'Z') || (token() == '+') || 
      	     (token() == '-') || (token() == '<') || 
      	     (token() == '=') || (token() == '>') || 
      	     (token() == '!') || (token() == '*') || 
      	     (token() == '/') || (token() == '1') || 
      	     (token() == ',') || (token() == '0')) {
         statemt();
      }
   }
   private void statemt() {
      if ((token() == 'A') || (token() == '~') || 
      	  (token() == '1') || (token() == '0') || 
      	  (token() == '*') || (token() == '/') || 
      	  (token() == '+') || (token() == '-') || 
      	  (token() == '0') || (token() == '1') || 
      	  (token() == 'X') || (token() == 'Y') || (token() == 'Z')) {
         asignmt();
      }
      if ((token() == 'I') || (token() == 'T') || 
      	  (token() == 'L') || (token() == '(') || 
      	  (token() == ')') || (token() == '1') || 
      	  (token() == '0') || (token() == '<') || 
      	  (token() == '=') || (token() == '>') || (token() == '!')) {
         ifstmt();
      }
      if (token() == 'W' || (token() == '(') || 
      	 (token() == ')') || (token() == '1') || 
      	 (token() == '0') || (token() == '<') || 
      	 (token() == '=') || (token() == '>') || (token() == '!')) {
         while1();
      }
      if ((token() == 'R') || (token() == 'O') || 
      	  (token() == 'X') || (token() == 'Y') || 
      	  (token() == 'Z') || (token() == '1') || 
      	  (token() == '0') || (token() == ',')) {
         inpout();
      }
      block();
   }

   private void asignmt() {
      if ((token() == 'A') || (token() == '~')) {
         match(token());
      }
      if ((token() == 'X') || (token() == 'Y') || 
      	  (token() == 'Z') || (token() == '1') || (token() == '0')) {
         ident();
      }
      if ((token() == '*') || (token() == '/') || 
      	  (token() == '+') || (token() == '-') || 
      	  (token() == '(') || (token() == ')') ||
      	  (token() == '0') || (token() == '1')) 
      	 exprsn();
   }
   private void ifstmt() {
      if ((token() == 'I') || (token() == 'T')) {
         match(token());
      }
      if ((token() == '(') || (token() == ')') || 
      	  (token() == '1') || (token() == '0') || 
      	  (token() == '<') || (token() == '=') || 
      	  (token() == '>') || (token() == '!')) 
      	comprsn();

        block(); //out of 'if' on purpose

   
      if (token() == 'L') {
         match(token());
         block();
      }
   }
   private void while1() {
      if (token() == 'W') {
         match(token());
      }
      if ((token() == '(') || (token() == ')') || 
      	  (token() == '1') || (token() == '0') || 
      	  (token() == '<') || (token() == '=') || 
      	  (token() == '>') || (token() == '!')) 
      	comprsn();
        
        block();
   }
   private void inpout() {
      if ((token() == 'R') || (token() == 'O')) iosym();
      if ((token() == 'X') || (token() == 'Y') || 
      	  (token() == 'Z') || (token() == '1') || 
      	  (token() == '0')) ident();
      while ((token() == ',') || (token() == '0') || 
      	     (token() == '1') || (token() == 'X') || (token() == 'Y') || (token() == 'Z')) {
         if ((token() == ',')) match(token());
         ident();
      }
   }
   private void comprsn() {
      if (token() == '(') {
         match(token());
      }
         oprnd();
         opratr();
         oprnd();
         if (token() == ')') {
            match(token());
         }   
   }

   private void exprsn() {
      if ((token() == 'X') || (token() == 'Y') || 
      	  (token() == 'Z') || (token() == '*') || 
      	  (token() == '/') || (token() == '1') || 
      	  (token() == '0') || (token() == '(') || 
      	  (token() == ')')) factor();
      
      if (token() == '(') {
         match(token());
      }
         sumop();
         factor();
         if (token() == ')') {
            match(token());
         } 
   }



   private void factor() {
      if ((token() == '1') || (token() == '0') || 
      	  (token() == '(') || (token() == ')')) oprnd();
      while ((token() == 'X') || (token() == 'Y') || 
      	     (token() == 'Z') || (token() == '*') || 
      	     (token() == '/') || (token() == '1') || 
      	     (token() == '0') || (token() == '(') || 
      	     (token() == ')')) {
         prodop();
         oprnd();
      }
   }

   private void oprnd() {
      if ((token() == '1') || (token() == '0')) integer();
      if ((token() == 'X') || (token() == 'Y') || 
      	  (token() == 'Z') || (token() == '1') || (token() == '0')) ident();
      if (token() == '(') {
         match(token());
      
         exprsn();
         if (token() == ')') {
            match(token());
         }
         else error();
      } 
      
   }
   private void ident() {
      if ((token() == 'X') || (token() == 'Y') || (token() == 'Z')) {
         letter();
      }
   
      while ((token() == '0') || (token() == '1') || (token() == 'X') || (token() == 'Y') || (token() == 'Z'))
         char1();
   }
   private void char1() {
      if ((token() == '0') || (token() == '1')) {
         digit();
      }
      if ((token() == 'X') || (token() == 'Y') || (token() == 'Z')) {
         letter();
      }
   }
   private void integer() {
      if ((token() == '0') || (token() == '1')) digit();
      while ((token() == '0') || (token() == '1')) digit();
   
   }
   private void iosym() {
      if ((token() == 'R') || (token() == 'O')) match(token());
      else error();
   }
   private void opratr() {
      if ((token() == '<') || (token() == '=') || (token() == '>') || (token() == '!')) match(token());
      else error();
   }
   private void sumop() {
      if ((token() == '+') || (token() == '-')) match(token());
      else error();
   }
   private void prodop() {
      if ((token() == '*') || (token() == '/')) match(token());
      else error();
   }
   private void letter() {
      if ((token() == 'X') || (token() == 'Y') || (token() == 'Z')) match(token());
      else error();
   }
   private void digit() {
      if ((token() == '0') || (token() == '1')) match(token());
      else error();
   }

 //----------------------
   private void start() {
      block();
      match('$');
      if (errorflag == 0)
         System.out.println("legal." + "\n");
      else
         System.out.println("errors found." + "\n");
   }
  //----------------------
   public static void main(String[] args) throws IOException {
      RDRecognizer rec = new RDRecognizer();
      Scanner input = new Scanner(System.in);
      System.out.print("\n" + "enter an expression: ");
      inputString = input.nextLine();
      rec.start();
   }
}